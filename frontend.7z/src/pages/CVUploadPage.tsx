import { useState, useCallback, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Upload, FileText, Download, AlertCircle, CheckCircle, ArrowLeft, FileJson, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { Header } from '@/components/Header';
import { Link } from 'react-router-dom';

interface UploadedFile {
  id: string;
  name: string;
  size: number;
  type: string;
  status: 'uploading' | 'processing' | 'completed' | 'error';
  progress: number;
  error?: string;
  pdfUrl?: string;
  extractedText?: string;
  originalFilename?: string;
}

interface JsonErrorDetails {
  error: boolean;
  error_message: string;
  raw_ai_response?: string;
  filename?: string;
  text_content_preview?: string;
  can_retry?: boolean;
}

const CVUploadPage = () => {
  const [files, setFiles] = useState<UploadedFile[]>([]);
  const [dragActive, setDragActive] = useState(false);
  const [selectedFile, setSelectedFile] = useState<UploadedFile | null>(null);
  const [jsonErrorDetails, setJsonErrorDetails] = useState<JsonErrorDetails | null>(null);
  const [currentJsonFile, setCurrentJsonFile] = useState<UploadedFile | null>(null);
  const [isProcessingJson, setIsProcessingJson] = useState(false);

  const API_BASE_URL = 'http://localhost:8000';

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    const droppedFiles = Array.from(e.dataTransfer.files);
    handleFiles(droppedFiles);
  }, []);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(e.target.files || []);
    handleFiles(selectedFiles);
  };

  const handleFiles = (newFiles: File[]) => {
    const newUploads: UploadedFile[] = newFiles.map(file => ({
      id: Math.random().toString(36).substr(2, 9),
      name: file.name,
      size: file.size,
      type: file.type,
      status: 'uploading',
      progress: 0
    }));

    setFiles(prev => [...prev, ...newUploads]);

    // Process each file with the backend API
    newUploads.forEach(file => {
      processFile(file, newFiles.find(f => f.name === file.name)!);
    });
  };

  const processFile = async (file: UploadedFile, originalFile: File) => {
    try {
      console.log('Starting to process file:', file.name);
      
      // Update status to processing
      setFiles(prev => prev.map(f => 
        f.id === file.id ? { ...f, status: 'processing', progress: 50 } : f
      ));

      // Create FormData and upload to backend
      const formData = new FormData();
      formData.append('file', originalFile);
      
      console.log('FormData created, file size:', originalFile.size);
      console.log('Uploading to:', `${API_BASE_URL}/upload-cv`);

      const response = await fetch(`${API_BASE_URL}/upload-cv`, {
        method: 'POST',
        body: formData,
      });

      console.log('Response status:', response.status);
      console.log('Response ok:', response.ok);

      if (!response.ok) {
        let errorMessage = 'Upload failed';
        let errorDetails = '';
        
        try {
          const errorData = await response.json();
          console.error('Error response:', errorData);
          errorMessage = errorData.detail || errorData.message || 'Upload failed';
          
          // Check if this is an OCR-related error
          if (errorMessage.includes('OCR') || errorMessage.includes('image-based')) {
            errorDetails = getOCRErrorDetails(errorMessage);
          }
        } catch (parseError) {
          console.error('Could not parse error response:', parseError);
          errorMessage = `Upload failed with status ${response.status}`;
        }
        
        // If we have OCR error details, include them
        if (errorDetails) {
          errorMessage = `${errorMessage}\n\n${errorDetails}`;
        }
        
        throw new Error(errorMessage);
      }

      const result = await response.json();
      console.log('Success response:', result);

      // Validate the response
      if (!result.file_id) {
        throw new Error('Backend did not return a file ID');
      }

      if (!result.text_content || result.text_content.trim() === '') {
        throw new Error('Backend did not extract any text content');
      }

      // Update file with real data from backend
      const updatedFile: UploadedFile = {
        ...file,
        status: 'completed' as const,
        progress: 100,
        pdfUrl: `${API_BASE_URL}/view-pdf/${result.file_id}`,
        extractedText: result.text_content,
        originalFilename: result.original_filename
      };

      setFiles(prev => prev.map(f => 
        f.id === file.id ? updatedFile : f
      ));

      // Automatically select the completed file to show PDF and text
      setSelectedFile(updatedFile);

      console.log('File updated in state with PDF URL:', `${API_BASE_URL}/view-pdf/${result.file_id}`);
      console.log('Text content length:', result.text_content?.length || 0);
      console.log('Automatically selected file for display');

      toast.success(`${file.name} processed successfully!`);
    } catch (error) {
      console.error('Error processing file:', error);
      const errorMessage = error instanceof Error ? error.message : 'Processing failed';
      
      setFiles(prev => prev.map(f => 
        f.id === file.id ? {
          ...f,
          status: 'error',
          error: errorMessage,
          progress: 0
        } : f
      ));

      // Show appropriate toast message based on error type
      if (errorMessage.includes('OCR') || errorMessage.includes('image-based')) {
        toast.error(`OCR Required: ${file.name} appears to be image-based`, {
          description: "This document needs OCR to extract text. Check the error details below.",
          duration: 8000,
        });
      } else {
        toast.error(`Failed to process ${file.name}: ${errorMessage}`);
      }
    }
  };

  const getOCRErrorDetails = (errorMessage: string): string => {
    if (errorMessage.includes('OCR is not available') || errorMessage.includes('install Tesseract')) {
      return `🔧 To fix this issue:

1. Install Tesseract OCR on your system:
   • Windows: Download from https://github.com/UB-Mannheim/tesseract/wiki
   • macOS: brew install tesseract
   • Ubuntu: sudo apt-get install tesseract-ocr

2. Restart the application
3. Try uploading your document again

💡 Tesseract OCR will enable text extraction from image-based PDFs and scanned documents.`;
    } else if (errorMessage.includes('OCR extraction failed') || errorMessage.includes('image quality')) {
      return `📸 Possible solutions for image-based documents:

1. Ensure the document images are clear and high quality
2. Check if the document has security restrictions
3. Try a different document with better image quality
4. Make sure the text in the images is readable and not too small

💡 OCR works best with clear, high-resolution images containing readable text.`;
    } else if (errorMessage.includes('image-based')) {
      return `🖼️ This document appears to be image-based (scanned or contains only images).

To extract text from images, you need:
1. Tesseract OCR installed on your system
2. Clear, readable images
3. Good image quality (300+ DPI recommended)

💡 Consider using the original document file (DOCX, PDF) instead of scanned versions.`;
    }
    
    return '';
  };

  const selectFile = (file: UploadedFile) => {
    console.log('Selecting file:', file);
    console.log('File status:', file.status);
    console.log('File PDF URL:', file.pdfUrl);
    console.log('File extracted text length:', file.extractedText?.length || 0);
    setSelectedFile(file);
  };

  // Debug effect for selected file
  useEffect(() => {
    if (selectedFile) {
      console.log('Selected file changed:', selectedFile);
      console.log('File status:', selectedFile.status);
      console.log('File PDF URL:', selectedFile.pdfUrl);
      console.log('File extracted text length:', selectedFile.extractedText?.length || 0);
      
      // Additional debug info for display rendering
      if (selectedFile.status === 'completed') {
        console.log('✅ File is completed, should display PDF and text');
        console.log('PDF URL for iframe:', selectedFile.pdfUrl);
        console.log('Text content preview:', selectedFile.extractedText?.substring(0, 100) + '...');
      }
    }
  }, [selectedFile]);

  // Debug effect for files array changes
  useEffect(() => {
    console.log('Files array changed:', files);
    console.log('Files with completed status:', files.filter(f => f.status === 'completed'));
  }, [files]);

  const removeFile = (fileId: string) => {
    setFiles(prev => prev.filter(f => f.id !== fileId));
    if (selectedFile?.id === fileId) {
      setSelectedFile(null);
    }
  };

  const resetAllFiles = () => {
    setFiles([]);
    setSelectedFile(null);
  };

  const downloadFile = async (file: UploadedFile) => {
    if (file.pdfUrl) {
      try {
        // Extract file_id from the URL
        const fileId = file.pdfUrl.split('/').pop();
        if (fileId) {
          const response = await fetch(`${API_BASE_URL}/download-pdf/${fileId}`);
          if (!response.ok) throw new Error('Download failed');

          const blob = await response.blob();
          const url = window.URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `${file.name.replace(/\.[^/.]+$/, '')}_converted.pdf`;
          document.body.appendChild(a);
          a.click();
          window.URL.revokeObjectURL(url);
          document.body.removeChild(a);
          toast.success('PDF downloaded successfully!');
        }
      } catch (error) {
        toast.error('Download failed');
      }
    }
  };

  const processJsonFile = async (file: UploadedFile) => {
    try {
      // Set current file and clear previous errors
      setCurrentJsonFile(file);
      setJsonErrorDetails(null);
      setIsProcessingJson(true);
      
      // Extract file_id from the URL
      const fileId = file.pdfUrl?.split('/').pop();
      if (!fileId) {
        toast.error('File not available for JSON processing');
        return;
      }

      toast.info('Processing file for JSON extraction...');
      
      const response = await fetch(`${API_BASE_URL}/process-json/${fileId}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          filename: file.originalFilename || file.name,
          extracted_text: file.extractedText || ''
        })
      });

      const result = await response.json();
      
      // Check if this is an error response
      if (result.error) {
        setJsonErrorDetails(result);
        toast.error('JSON processing failed - check details below');
        return;
      }

      if (!response.ok) {
        throw new Error('JSON processing failed');
      }
      
      // Download the JSON file
      const blob = new Blob([JSON.stringify(result, null, 2)], { type: 'application/json' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${file.name.replace(/\.[^/.]+$/, '')}_extracted.json`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast.success('JSON extraction completed successfully!');
      setCurrentJsonFile(null);
    } catch (error) {
      console.error('JSON processing error:', error);
      toast.error('JSON processing failed');
      setCurrentJsonFile(null);
    } finally {
      setIsProcessingJson(false);
    }
  };

  const retryJsonProcessing = async () => {
    if (currentJsonFile) {
      await processJsonFile(currentJsonFile);
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getStatusIcon = (status: UploadedFile['status']) => {
    switch (status) {
      case 'uploading':
        return <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-500" />;
      case 'processing':
        return <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-yellow-500" />;
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'error':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
      default:
        return null;
    }
  };

  const getStatusBadge = (status: UploadedFile['status']) => {
    const variants = {
      uploading: 'bg-blue-100 text-blue-800',
      processing: 'bg-yellow-100 text-yellow-800',
      completed: 'bg-green-100 text-green-800',
      error: 'bg-red-100 text-red-800'
    };

    return (
      <Badge className={variants[status]}>
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </Badge>
    );
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="container mx-auto p-6 space-y-6">
        {/* Back to Dashboard Button */}
        <div className="flex items-center gap-4 mb-4">
          <Link to="/">
            <Button variant="ghost" size="sm" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back to Dashboard
            </Button>
          </Link>
        </div>
        
        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold">CV Document Upload & Conversion</h1>
          <p className="text-muted-foreground">
            Upload CV documents and convert them to PDF with text extraction
          </p>
          

        </div>

        {/* Initial Screen: Upload Section and How It Works Side by Side */}
        {files.length === 0 ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Upload Section - Left Side */}
            <Card>
              <CardHeader>
                <CardTitle>Upload CV Documents</CardTitle>
                <CardDescription>
                  Drag and drop your CV files here or click to browse. All documents will be converted to PDF.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div
                  className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                    dragActive 
                      ? 'border-blue-500 bg-blue-50' 
                      : 'border-gray-300 hover:border-gray-400'
                  }`}
                  onDragEnter={handleDrag}
                  onDragLeave={handleDrag}
                  onDragOver={handleDrag}
                  onDrop={handleDrop}
                >
                  <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                  <p className="text-lg font-medium text-gray-900 mb-2">
                    Drop your CV files here
                  </p>
                  <p className="text-sm text-gray-500 mb-4">
                    or click to browse files
                  </p>
                  <Button onClick={() => document.getElementById('file-input')?.click()}>
                    Choose Files
                  </Button>
                  <input
                    id="file-input"
                    type="file"
                    multiple
                    accept=".pdf,.docx,.doc,.txt,.rtf,.jpg,.jpeg,.png,.bmp,.tiff"
                    className="hidden"
                    onChange={handleFileSelect}
                  />
                </div>

                {/* Supported Formats Info */}
                <div className="mt-4 text-sm text-muted-foreground">
                  <p className="font-medium mb-2">Supported input formats:</p>
                  <div className="flex flex-wrap gap-2">
                    {['PDF', 'DOCX', 'DOC', 'TXT', 'RTF', 'JPG', 'JPEG', 'PNG', 'BMP', 'TIFF'].map(format => (
                      <Badge key={format} variant="secondary" className="text-xs">
                        {format}
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* How It Works - Right Side */}
            <Card>
              <CardHeader>
                <CardTitle>How it works</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-start space-x-3">
                  <div className="bg-blue-100 rounded-full p-2 mt-0.5">
                    <Upload className="h-4 w-4 text-blue-600" />
                  </div>
                  <div>
                    <p className="font-medium text-sm">1. Upload CV Document</p>
                    <p className="text-xs text-muted-foreground">
                      Select or drag your CV file (PDF, DOCX, DOC, TXT, RTF, or image formats)
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="bg-yellow-100 rounded-full p-2 mt-0.5">
                    <FileText className="h-4 w-4 text-yellow-600" />
                  </div>
                  <div>
                    <p className="font-medium text-sm">2. Automatic Conversion</p>
                    <p className="text-xs text-muted-foreground">
                      Document is automatically converted to PDF and text is extracted
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="bg-green-100 rounded-full p-2 mt-0.5">
                    <Download className="h-4 w-4 text-green-600" />
                  </div>
                  <div>
                    <p className="font-medium text-sm">3. View & Download</p>
                    <p className="text-xs text-muted-foreground">
                      Preview PDF on left, read extracted text on right, download when ready
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        ) : (
          /* When files are uploaded: Upload Section and File List Side by Side */
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Upload Section - Left Side */}
            <Card>
              <CardHeader>
                <CardTitle>Upload CV Documents</CardTitle>
                <CardDescription>
                  Drag and drop your CV files here or click to browse. All documents will be converted to PDF.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div
                  className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                    dragActive 
                      ? 'border-blue-500 bg-blue-50' 
                      : 'border-gray-300 hover:border-gray-400'
                  }`}
                  onDragEnter={handleDrag}
                  onDragLeave={handleDrag}
                  onDragOver={handleDrag}
                  onDrop={handleDrop}
                >
                  <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                  <p className="text-lg font-medium text-gray-900 mb-2">
                    Drop your CV files here
                  </p>
                  <p className="text-sm text-gray-500 mb-4">
                    or click to browse files
                  </p>
                  <Button onClick={() => document.getElementById('file-input')?.click()}>
                    Choose Files
                  </Button>
                  <input
                    id="file-input"
                    type="file"
                    multiple
                    accept=".pdf,.docx,.doc,.txt,.rtf,.jpg,.jpeg,.png,.bmp,.tiff"
                    className="hidden"
                    onChange={handleFileSelect}
                  />
                </div>

                {/* Supported Formats Info */}
                <div className="mt-4 text-sm text-muted-foreground">
                  <p className="font-medium mb-2">Supported input formats:</p>
                  <div className="flex flex-wrap gap-2">
                    {['PDF', 'DOCX', 'DOC', 'TXT', 'RTF', 'JPG', 'JPEG', 'PNG', 'BMP', 'TIFF'].map(format => (
                      <Badge key={format} variant="secondary" className="text-xs">
                        {format}
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* File List - Right Side */}
            <div className="space-y-4">
              <Card className="max-h-80">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg">Uploaded Files</CardTitle>
                  <CardDescription>
                    {files.length} file{files.length !== 1 ? 's' : ''} uploaded
                  </CardDescription>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="space-y-2 max-h-48 overflow-y-auto">
                    {files.map((file) => (
                      <div
                        key={file.id}
                        className={`flex items-center justify-between p-2 border rounded-lg cursor-pointer transition-colors ${
                          selectedFile?.id === file.id 
                            ? 'border-blue-500 bg-blue-50' 
                            : 'hover:bg-gray-50'
                        }`}
                        onClick={() => file.status === 'completed' && selectFile(file)}
                      >
                        <div className="flex items-center space-x-2 flex-1 min-w-0">
                          <FileText className="h-4 w-4 text-gray-400 flex-shrink-0" />
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-xs truncate">{file.name}</p>
                            <p className="text-xs text-muted-foreground">
                              {formatFileSize(file.size)} • {file.type}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center space-x-2 flex-shrink-0">
                          {getStatusIcon(file.status)}
                          {getStatusBadge(file.status)}
                          
                          {file.status === 'completed' && (
                            <Button
                              size="sm"
                              variant="outline"
                              className="h-7 px-2 text-xs"
                              onClick={(e) => {
                                e.stopPropagation();
                                downloadFile(file);
                              }}
                            >
                              <Download className="h-3 w-3 mr-1" />
                              Download
                            </Button>
                          )}

                          <Button
                            size="sm"
                            variant="outline"
                            className="h-7 px-2 text-xs"
                            onClick={(e) => {
                              e.stopPropagation();
                              processJsonFile(file);
                            }}
                            disabled={isProcessingJson}
                          >
                            {isProcessingJson && currentJsonFile?.id === file.id ? (
                              <Loader2 className="h-3 w-3 mr-1 animate-spin" />
                            ) : (
                              <FileJson className="h-3 w-3 mr-1" />
                            )}
                            {isProcessingJson && currentJsonFile?.id === file.id ? 'Processing...' : 'Json'}
                          </Button>

                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-7 px-2 text-xs"
                            onClick={(e) => {
                              e.stopPropagation();
                              removeFile(file.id);
                            }}
                          >
                            Remove
                          </Button>
                        </div>

                        {/* Progress Bar */}
                        {file.status === 'uploading' && (
                          <div className="absolute bottom-0 left-0 right-0 h-1 bg-gray-200 rounded-b-lg">
                            <div
                              className="h-full bg-blue-500 transition-all duration-300 rounded-b-lg"
                              style={{ width: `${file.progress}%` }}
                            />
                          </div>
                        )}

                        {/* Error Details */}
                        {file.status === 'error' && file.error && (
                          <div className="mt-2 p-3 bg-red-50 border border-red-200 rounded-lg">
                            <div className="flex items-start space-x-2">
                              <AlertCircle className="h-4 w-4 text-red-500 mt-0.5 flex-shrink-0" />
                              <div className="flex-1">
                                <p className="text-sm font-medium text-red-800 mb-1">Processing Error</p>
                                <p className="text-xs text-red-700 whitespace-pre-line">{file.error}</p>
                                
                                {/* Show OCR-specific help */}
                                {file.error.includes('OCR') && (
                                  <div className="mt-2 p-2 bg-blue-50 border border-blue-200 rounded">
                                    <p className="text-xs font-medium text-blue-800 mb-1">💡 Need help with OCR?</p>
                                    <p className="text-xs text-blue-700">
                                      This document appears to be image-based. Check the error details above for installation instructions.
                                    </p>
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* JSON Error Display Section */}
              {jsonErrorDetails && (
                <Card className="border-red-200 bg-red-50">
                  <CardHeader>
                    <CardTitle className="text-red-800 flex items-center gap-2">
                      <AlertCircle className="h-5 w-5" />
                      JSON Processing Error
                    </CardTitle>
                    <CardDescription className="text-red-700">
                      Failed to process {jsonErrorDetails.filename || 'file'} for JSON extraction
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="bg-white p-3 rounded border border-red-200">
                      <h4 className="font-medium text-red-800 mb-2">Error Details:</h4>
                      <p className="text-sm text-red-700">{jsonErrorDetails.error_message}</p>
                    </div>
                    
                    {jsonErrorDetails.text_content_preview && (
                      <div className="bg-white p-3 rounded border border-red-200">
                        <h4 className="font-medium text-red-800 mb-2">Text Content Preview:</h4>
                        <p className="text-sm text-gray-700 whitespace-pre-wrap max-h-32 overflow-auto">
                          {jsonErrorDetails.text_content_preview}
                        </p>
                      </div>
                    )}
                    
                    {jsonErrorDetails.raw_ai_response && (
                      <div className="bg-white p-3 rounded border border-red-200">
                        <h4 className="font-medium text-red-800 mb-2">Raw AI Response:</h4>
                        <p className="text-sm text-gray-700 whitespace-pre-wrap max-h-32 overflow-auto font-mono">
                          {jsonErrorDetails.raw_ai_response}
                        </p>
                      </div>
                    )}
                    
                    <div className="flex gap-2">
                      {jsonErrorDetails.can_retry && (
                        <Button 
                          onClick={retryJsonProcessing}
                          disabled={isProcessingJson}
                          className="bg-red-600 hover:bg-red-700"
                        >
                          {isProcessingJson ? (
                            <>
                              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                              Retrying...
                            </>
                          ) : (
                            'Retry Processing'
                          )}
                        </Button>
                      )}
                      <Button 
                        variant="outline"
                        onClick={() => setJsonErrorDetails(null)}
                      >
                        Dismiss
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Reset Button Section */}
              <Card>
                <CardContent className="pt-4">
                  <Button
                    onClick={resetAllFiles}
                    className="w-full"
                  >
                    Reset
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        )}

        {/* PDF Viewer and Text Content - Equal Size */}
        {selectedFile && selectedFile.status === 'completed' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* PDF Viewer - Left Side */}
            <Card>
              <CardHeader>
                <CardTitle>Converted PDF</CardTitle>
                <CardDescription>
                  {selectedFile.originalFilename || selectedFile.name} - PDF Preview
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="border rounded-lg bg-gray-50 h-[600px]">
                  {selectedFile.pdfUrl ? (
                    <iframe 
                      src={selectedFile.pdfUrl} 
                      className="w-full h-full border-0"
                      title="PDF Preview"
                    />
                  ) : (
                    <div className="p-4 flex items-center justify-center h-full">
                      <div className="text-center">
                        <FileText className="mx-auto h-16 w-16 text-gray-400 mb-4" />
                        <p className="text-lg font-medium text-gray-900 mb-2">
                          PDF Preview Unavailable
                        </p>
                        <p className="text-sm text-gray-500 mb-4">
                          PDF could not be loaded
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Extracted Text - Right Side */}
            <Card>
              <CardHeader>
                <CardTitle>Extracted Text Content</CardTitle>
                <CardDescription>
                  Text content from {selectedFile.originalFilename || selectedFile.name}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="border rounded-lg p-4 bg-white h-[600px] overflow-auto">
                  <div className="prose max-w-none">
                    <p className="text-sm text-gray-700 whitespace-pre-wrap">
                      {selectedFile.extractedText || 'No text content available'}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Show completed files that aren't selected */}
        {files.filter(f => f.status === 'completed').length > 0 && !selectedFile && (
          <Card className="bg-blue-50 border-blue-200">
            <CardHeader>
              <CardTitle className="text-blue-800">Files Ready for Viewing</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-blue-700 mb-3">
                You have {files.filter(f => f.status === 'completed').length} processed file(s). Click on any completed file above to view the PDF and extracted text.
              </p>
              <div className="space-y-2">
                {files.filter(f => f.status === 'completed').map(file => (
                  <div key={file.id} className="flex items-center justify-between p-2 bg-white rounded border">
                    <span className="text-sm font-medium">{file.name}</span>
                    <Button 
                      size="sm" 
                      onClick={() => selectFile(file)}
                      className="bg-blue-600 hover:bg-blue-700"
                    >
                      View Content
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}


      </div>
    </div>
  );
};

export default CVUploadPage;
