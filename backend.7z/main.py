from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
import os
import uuid
import json
from typing import Optional
import aiofiles
from pathlib import Path

from services.document_processor import DocumentProcessor
from services.file_converter import FileConverter
from services.text_extractor import TextExtractor

app = FastAPI(title="CV Transform API", version="1.0.0")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:3000"],  # Frontend URLs
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Create upload and temp directories
UPLOAD_DIR = Path("uploads")
TEMP_DIR = Path("temp")
UPLOAD_DIR.mkdir(exist_ok=True)
TEMP_DIR.mkdir(exist_ok=True)

# Initialize services
document_processor = DocumentProcessor()
file_converter = FileConverter()
text_extractor = TextExtractor()

@app.get("/")
async def root():
    return {"message": "CV Transform API is running"}

@app.post("/upload-cv")
async def upload_cv(file: UploadFile = File(...)):
    """
    Upload a CV document and process it
    """
    try:
        # Validate file type
        allowed_extensions = {'.pdf', '.doc', '.docx', '.rtf', '.txt', '.json', '.jpg', '.jpeg', '.png', '.bmp', '.tiff'}
        file_extension = Path(file.filename).suffix.lower()
        
        if file_extension not in allowed_extensions:
            raise HTTPException(
                status_code=400, 
                detail=f"File type not supported. Allowed types: {', '.join(allowed_extensions)}"
            )
        
        # Generate unique filename
        file_id = str(uuid.uuid4())
        # Sanitize the original filename to avoid issues with special characters
        safe_filename = file.filename.replace('\\', '_').replace('/', '_').replace(':', '_')
        original_filename = f"{file_id}_{safe_filename}"
        original_path = UPLOAD_DIR / original_filename
        
        # Save uploaded file
        async with aiofiles.open(original_path, 'wb') as f:
            content = await file.read()
            await f.write(content)
        
        print(f"File saved: {original_path}")
        
        # Process the document
        print(f"Processing document: {original_path}")
        try:
            result = await document_processor.process_document(original_path, file_extension)
            print(f"Processing result: {result}")
        except Exception as process_error:
            print(f"Document processing failed: {process_error}")
            # Clean up the uploaded file
            if original_path.exists():
                original_path.unlink()
            raise HTTPException(
                status_code=500, 
                detail=f"Document processing failed: {str(process_error)}"
            )
        
        # Validate the result
        if not result.get("text_content") or result["text_content"].strip() == "":
            print("❌ Text extraction failed - no content extracted")
            # Clean up the uploaded file
            if original_path.exists():
                original_path.unlink()
            raise HTTPException(
                status_code=500, 
                detail="Text extraction failed - no content was extracted from the document. This might be an image-based document or the conversion failed."
            )
        
        if not result.get("pdf_path"):
            print("❌ PDF conversion failed - no PDF created")
            # Clean up the uploaded file
            if original_path.exists():
                original_path.unlink()
            raise HTTPException(
                status_code=500, 
                detail="PDF conversion failed - no PDF was created. Please try a different file format."
            )
        
        print(f"✅ Processing successful - Text length: {len(result.get('text_content', ''))}")
        
        return {
            "success": True,
            "file_id": file_id,
            "original_filename": file.filename,
            "pdf_path": result["pdf_path"],
            "text_content": result["text_content"],
            "file_type": file_extension,
            "conversion_method": result.get("conversion_method", "unknown")
        }
        
    except HTTPException:
        # Re-raise HTTP exceptions as-is
        raise
    except Exception as e:
        print(f"Unexpected error in upload_cv: {e}")
        # Clean up the uploaded file if it exists
        if 'original_path' in locals() and original_path.exists():
            original_path.unlink()
        raise HTTPException(status_code=500, detail=f"Upload failed: {str(e)}")

@app.get("/download-pdf/{file_id}")
async def download_pdf(file_id: str):
    """
    Download the converted PDF file
    """
    try:
        # Look for PDF files that start with the file_id and end with .pdf
        # The file converter creates files like: {file_id}_{original_filename}.pdf
        pdf_files = list(UPLOAD_DIR.glob(f"{file_id}*.pdf"))
        
        if not pdf_files:
            raise HTTPException(status_code=404, detail="PDF file not found")
        
        pdf_path = pdf_files[0]  # Take the first matching file
        
        return FileResponse(
            path=pdf_path,
            filename=f"{file_id}_converted.pdf",
            media_type="application/pdf"
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/view-pdf/{file_id}")
async def view_pdf(file_id: str):
    """
    View the converted PDF file in browser (for iframe display)
    """
    try:
        print(f"🔍 Looking for PDF files with file_id: {file_id}")
        print(f"🔍 Upload directory: {UPLOAD_DIR}")
        
        # Look for PDF files that start with the file_id and end with .pdf
        # The file converter creates files like: {file_id}_{original_filename}.pdf
        pdf_files = list(UPLOAD_DIR.glob(f"{file_id}*.pdf"))
        print(f"🔍 PDF files found: {pdf_files}")
        print(f"🔍 Count: {len(pdf_files)}")
        
        if not pdf_files:
            print(f"❌ No PDF files found for file_id: {file_id}")
            raise HTTPException(status_code=404, detail="PDF file not found")
        
        pdf_path = pdf_files[0]  # Take the first matching file
        print(f"🔍 Selected PDF path: {pdf_path}")
        print(f"🔍 Path exists: {pdf_path.exists()}")
        print(f"🔍 Path is file: {pdf_path.is_file()}")
        print(f"🔍 File size: {pdf_path.stat().st_size if pdf_path.exists() else 'N/A'}")
        
        return FileResponse(
            path=pdf_path,
            media_type="application/pdf",
            headers={"Content-Disposition": "inline"}
        )
    except Exception as e:
        print(f"❌ Error in view-pdf endpoint: {e}")
        print(f"❌ Exception type: {type(e)}")
        import traceback
        print(f"❌ Traceback: {traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/document/{file_id}")
async def get_document_info(file_id: str):
    """
    Get document information and text content
    """
    try:
        text_path = UPLOAD_DIR / f"{file_id}_text.txt"
        
        # Look for PDF files that start with the file_id and end with .pdf
        # The file converter creates files like: {file_id}_{original_filename}.pdf
        pdf_files = list(UPLOAD_DIR.glob(f"{file_id}*.pdf"))
        pdf_exists = len(pdf_files) > 0
        
        if not text_path.exists():
            raise HTTPException(status_code=404, detail="Document not found")
        
        # Read text content
        async with aiofiles.open(text_path, 'r', encoding='utf-8') as f:
            text_content = await f.read()
        
        return {
            "file_id": file_id,
            "text_content": text_content,
            "pdf_exists": pdf_exists,
            "text_length": len(text_content)
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.delete("/document/{file_id}")
async def delete_document(file_id: str):
    """
    Delete uploaded document and its processed files
    """
    try:
        # Find all files with this file_id
        files_to_delete = []
        for file_path in UPLOAD_DIR.glob(f"{file_id}*"):
            files_to_delete.append(file_path)
        
        # Delete files
        for file_path in files_to_delete:
            if file_path.exists():
                file_path.unlink()
        
        return {"success": True, "message": f"Deleted {len(files_to_delete)} files"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/process-json/{file_id}")
async def process_json(file_id: str, request_data: dict):
    """
    Process a document to extract structured JSON using OpenRouter AI
    """
    try:
        from services.ai_processor import AIProcessor
        
        # Initialize AI processor
        ai_processor = AIProcessor()
        
        # Get the extracted text content
        text_path = UPLOAD_DIR / f"{file_id}_text.txt"
        if not text_path.exists():
            raise HTTPException(status_code=404, detail="Text content not found")
        
        # Read text content
        async with aiofiles.open(text_path, 'r', encoding='utf-8') as f:
            text_content = await f.read()
        
        # Process with AI
        result = await ai_processor.process_cv_to_json(
            filename=request_data.get("filename", ""),
            text_content=text_content
        )
        
        return result
        
    except Exception as e:
        print(f"Error in JSON processing: {e}")
        error_detail = str(e)
        
        # Try to parse error details if it's JSON
        try:
            import json
            error_data = json.loads(error_detail)
            if isinstance(error_data, dict) and error_data.get("error"):
                # Return structured error information
                return {
                    "error": True,
                    "error_message": error_data.get("error_message", "Unknown error"),
                    "raw_ai_response": error_data.get("raw_ai_response"),
                    "filename": error_data.get("filename"),
                    "text_content_preview": error_data.get("text_content_preview"),
                    "can_retry": True
                }
        except:
            pass
        
        # Fallback to simple error
        raise HTTPException(status_code=500, detail=f"JSON processing failed: {error_detail}")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
