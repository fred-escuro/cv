import asyncio
import sys
from pathlib import Path
from services.file_converter import FileConverter
from services.text_extractor import TextExtractor
from services.document_processor import DocumentProcessor

async def debug_docx_file(docx_path: str):
    """Debug a specific DOCX file to identify conversion issues"""
    print(f"🔍 Debugging DOCX file: {docx_path}")
    
    if not Path(docx_path).exists():
        print(f"❌ File not found: {docx_path}")
        return
    
    file_path = Path(docx_path)
    
    # Check file properties
    print(f"\n📁 File Information:")
    print(f"   Size: {file_path.stat().st_size} bytes")
    print(f"   Extension: {file_path.suffix}")
    print(f"   Filename: {file_path.name}")
    
    # Check if it's a valid DOCX file
    try:
        from docx import Document
        doc = Document(docx_path)
        print(f"   ✅ Valid DOCX file - {len(doc.paragraphs)} paragraphs")
        
        # Check for complex content
        has_tables = len(doc.tables) > 0
        has_images = len(doc.inline_shapes) > 0
        has_headers = len(doc.sections) > 0
        
        print(f"   📊 Contains tables: {has_tables}")
        print(f"   🖼️  Contains images: {has_images}")
        print(f"   📄 Contains headers/footers: {has_headers}")
        
        # Check first few paragraphs for content
        print(f"   📝 First few paragraphs:")
        for i, para in enumerate(doc.paragraphs[:3]):
            if para.text.strip():
                print(f"      {i+1}: {para.text[:100]}...")
        
    except Exception as e:
        print(f"   ❌ Invalid or corrupted DOCX file: {e}")
        return
    
    # Test conversion methods individually
    print(f"\n🔄 Testing Conversion Methods:")
    
    fc = FileConverter()
    pdf_path = file_path.with_suffix('.pdf')
    
    # Test 1: LibreOffice
    print(f"\n   1. LibreOffice conversion:")
    try:
        result = await fc._convert_with_libreoffice(file_path, pdf_path)
        print(f"      Result: {result}")
    except Exception as e:
        print(f"      Error: {e}")
    
    # Test 2: Pandoc
    print(f"\n   2. Pandoc conversion:")
    try:
        result = await fc._convert_with_pandoc(file_path, pdf_path)
        print(f"      Result: {result}")
    except Exception as e:
        print(f"      Error: {e}")
    
    # Test 3: docx2pdf
    print(f"\n   3. docx2pdf conversion:")
    try:
        result = await fc._convert_with_docx2pdf(file_path, pdf_path)
        print(f"      Result: {result}")
        if result and pdf_path.exists():
            print(f"      PDF size: {pdf_path.stat().st_size} bytes")
    except Exception as e:
        print(f"      Error: {e}")
    
    # Test 4: Manual conversion
    print(f"\n   4. Manual conversion:")
    try:
        result = await fc._convert_docx_manual(file_path, pdf_path)
        print(f"      Result: {result}")
    except Exception as e:
        print(f"      Error: {e}")
    
    # Test 5: Full pipeline
    print(f"\n   5. Full conversion pipeline:")
    try:
        result = await fc.convert_to_pdf(file_path, '.docx')
        print(f"      Result: {result}")
        if result and result.exists():
            print(f"      PDF size: {result.stat().st_size} bytes")
            
            # Test text extraction
            print(f"\n   6. Text extraction test:")
            te = TextExtractor()
            text_content = await te.extract_text_from_pdf(result)
            print(f"      Text length: {len(text_content) if text_content else 0}")
            if text_content:
                print(f"      First 200 chars: {text_content[:200]}...")
            
    except Exception as e:
        print(f"      Error: {e}")
        import traceback
        traceback.print_exc()

async def main():
    """Main function to debug DOCX issues"""
    if len(sys.argv) != 2:
        print("Usage: python debug_docx_issue.py <path_to_docx_file>")
        print("Example: python debug_docx_issue.py uploads/app147212-114793-valerio-gian-yuri-bondoc-.docx")
        return
    
    docx_path = sys.argv[1]
    await debug_docx_file(docx_path)

if __name__ == "__main__":
    asyncio.run(main())
