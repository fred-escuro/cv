import os
import json
import aiohttp
from dotenv import load_dotenv
from typing import Dict, Any, Optional
from pathlib import Path

# Load environment variables
load_dotenv()

class AIProcessor:
    def __init__(self):
        self.api_key = os.getenv('OPENROUTER_API_KEY')
        self.base_url = os.getenv('OPENROUTER_BASE_URL', 'https://openrouter.ai/api/v1')
        
        # Primary model and fallback models
        self.primary_model = os.getenv('OPENROUTER_MODEL', 'anthropic/claude-3.5-sonnet')
        self.fallback_models = [
            os.getenv('OPENROUTER_FALLBACK_MODEL_1', 'openai/gpt-4o'),
            os.getenv('OPENROUTER_FALLBACK_MODEL_2', 'anthropic/claude-3-haiku'),
            os.getenv('OPENROUTER_FALLBACK_MODEL_3', 'meta-llama/llama-3.1-8b-instruct')
        ]
        
        if not self.api_key:
            raise ValueError("OPENROUTER_API_KEY environment variable is required")
    
    async def process_cv_to_json(self, filename: str, text_content: str) -> Dict[str, Any]:
        """
        Process CV text content and extract structured information using OpenRouter AI
        Tries multiple models if the primary model fails
        """
        # Try primary model first
        models_to_try = [self.primary_model] + self.fallback_models
        last_error = None
        
        for i, model in enumerate(models_to_try):
            try:
                print(f"Trying model {i+1}/{len(models_to_try)}: {model}")
                
                # Create the AI prompt
                prompt = self._create_cv_prompt(filename, text_content)
                
                # Call OpenRouter API with current model
                ai_response = await self._call_openrouter_api(prompt, model)
                
                # Parse and validate the response
                result = self._parse_ai_response(ai_response)
                
                print(f"Successfully processed with model: {model}")
                return result
                
            except Exception as e:
                print(f"Model {model} failed: {str(e)}")
                last_error = e
                
                # If this is the last model, raise the error
                if i == len(models_to_try) - 1:
                    break
                
                # Continue to next model
                continue
        
        # All models failed, return error details for frontend display
        error_details = {
            "error": True,
            "error_message": f"All models failed. Last error: {str(last_error)}",
            "raw_ai_response": getattr(last_error, 'raw_response', None),
            "filename": filename,
            "text_content_preview": text_content[:500] + "..." if len(text_content) > 500 else text_content,
            "models_tried": models_to_try
        }
        raise Exception(json.dumps(error_details))
    
    def _create_cv_prompt(self, filename: str, text_content: str) -> str:
        """
        Create the AI prompt for CV parsing
        """
        prompt = f"""Please analyze the following CV document and extract detailed information into a structured JSON format.

Document: {filename}

CV Content:
{text_content}

Please extract the following information and format it as a valid JSON object:

{{
  "personal_info": {{
    "full_name": "string",
    "email": "string",
    "phone": "string",
    "address": "string",
    "linkedin": "string",
    "website": "string",
    "summary": "string"
  }},
  "education": [
    {{
      "degree": "string",
      "field_of_study": "string",
      "institution": "string",
      "graduation_year": "string",
      "gpa": "string",
      "achievements": "string"
    }}
  ],
  "work_experience": [
    {{
      "job_title": "string",
      "company": "string",
      "location": "string",
      "start_date": "string",
      "end_date": "string",
      "current": "boolean",
      "description": "string",
      "achievements": ["string"],
      "technologies": ["string"]
    }}
  ],
  "skills": {{
    "technical_skills": ["string"],
    "soft_skills": ["string"],
    "languages": ["string"],
    "certifications": ["string"]
  }},
  "projects": [
    {{
      "name": "string",
      "description": "string",
      "technologies": ["string"],
      "url": "string",
      "github": "string"
    }}
  ],
  "achievements": ["string"],
  "interests": ["string"],
  "volunteer_work": [
    {{
      "organization": "string",
      "role": "string",
      "duration": "string",
      "description": "string"
    }}
  ]
}}

Important:
1. Extract as much information as possible from the CV content
2. If a field is not available in the CV, use null or empty string as appropriate
3. Ensure the response is valid JSON format
4. Do not include any explanations or text outside the JSON structure
5. Use arrays for multiple items (e.g., multiple skills, experiences)
6. For dates, use the format as found in the CV or ISO format if possible
7. For boolean values, use true/false
8. If the CV content is unclear or incomplete, make reasonable inferences based on context

Please provide only the JSON response without any additional text or formatting."""
        
        return prompt
    
    async def _call_openrouter_api(self, prompt: str, model: str) -> str:
        """
        Call OpenRouter API with the CV processing prompt and specified model
        """
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": "https://cv-transform-app.com",
            "X-Title": "CV Transform App"
        }
        
        payload = {
            "model": model,
            "messages": [
                {
                    "role": "system",
                    "content": "You are a CV parsing assistant. Always respond with valid JSON only. Do not include any explanations, markdown formatting, or additional text outside the JSON structure."
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            "max_tokens": 4000,
            "temperature": 0.1,
            "response_format": {"type": "json_object"}
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.post(
                f"{self.base_url}/chat/completions",
                headers=headers,
                json=payload
            ) as response:
                if response.status != 200:
                    error_text = await response.text()
                    raise Exception(f"OpenRouter API error: {response.status} - {error_text}")
                
                result = await response.json()
                return result['choices'][0]['message']['content']
    
    def _parse_ai_response(self, ai_response: str) -> Dict[str, Any]:
        """
        Parse and validate the AI response
        """
        try:
            # Try to parse the response as JSON
            result = json.loads(ai_response)
            
            # Validate that it's a dictionary
            if not isinstance(result, dict):
                raise Exception("AI response is not a valid JSON object")
            
            return result
            
        except json.JSONDecodeError as e:
            print(f"Failed to parse AI response as JSON: {e}")
            print(f"AI Response: {ai_response}")
            # Create custom exception with raw response
            error_exception = Exception("AI response could not be parsed as valid JSON")
            error_exception.raw_response = ai_response
            raise error_exception
        except Exception as e:
            print(f"Error parsing AI response: {e}")
            raise
    
    def _validate_json_structure(self, data: Dict[str, Any]) -> None:
        """
        Validate that the JSON has the expected structure
        """
        required_sections = ["personal_info", "work_experience", "education", "skills"]
        
        for section in required_sections:
            if section not in data:
                print(f"Warning: Missing required section: {section}")
        
        # Ensure personal_info has at least a name
        if "personal_info" in data and not data["personal_info"].get("full_name"):
            print("Warning: No full name found in personal_info")
        
        # Ensure work_experience is an array
        if "work_experience" in data and not isinstance(data["work_experience"], list):
            print("Warning: work_experience should be an array")
        
        # Ensure education is an array
        if "education" in data and not isinstance(data["education"], list):
            print("Warning: education should be an array")
