import asyncio
import sys
from pathlib import Path
from services.file_converter import FileConverter

async def check_file_health(file_path: str):
    """Check the health of a specific DOCX file"""
    print(f"🔍 Checking file health: {file_path}")
    
    if not Path(file_path).exists():
        print(f"❌ File not found: {file_path}")
        return
    
    file_path_obj = Path(file_path)
    
    # Basic file information
    print(f"\n📁 File Information:")
    print(f"   Path: {file_path_obj.absolute()}")
    print(f"   Size: {file_path_obj.stat().st_size} bytes")
    print(f"   Extension: {file_path_obj.suffix}")
    print(f"   Filename: {file_path_obj.name}")
    
    # Check if it's a valid DOCX file
    print(f"\n🔍 DOCX Validation:")
    try:
        from docx import Document
        doc = Document(file_path)
        print(f"   ✅ Valid DOCX file")
        print(f"   📝 Paragraphs: {len(doc.paragraphs)}")
        print(f"   📊 Tables: {len(doc.tables)}")
        print(f"   🖼️  Images: {len(doc.inline_shapes)}")
        print(f"   📄 Sections: {len(doc.sections)}")
        
        # Check for content
        text_content = []
        for para in doc.paragraphs:
            if para.text.strip():
                text_content.append(para.text.strip())
        
        print(f"   📝 Non-empty paragraphs: {len(text_content)}")
        if text_content:
            print(f"   📝 First paragraph: {text_content[0][:100]}...")
            print(f"   📝 Last paragraph: {text_content[-1][:100]}...")
        
        # Check for complex elements
        has_complex_content = len(doc.tables) > 0 or len(doc.inline_shapes) > 0
        print(f"   ⚠️  Has complex content: {has_complex_content}")
        
    except Exception as e:
        print(f"   ❌ Invalid or corrupted DOCX file: {e}")
        return
    
    # Test conversion methods
    print(f"\n🔄 Conversion Method Tests:")
    
    fc = FileConverter()
    pdf_path = file_path_obj.with_suffix('.pdf')
    
    # Test each method individually
    methods = [
        ("LibreOffice", fc._convert_with_libreoffice),
        ("Pandoc", fc._convert_with_pandoc),
        ("docx2pdf", fc._convert_with_docx2pdf),
        ("Manual", fc._convert_docx_manual)
    ]
    
    for method_name, method_func in methods:
        print(f"\n   {method_name}:")
        try:
            result = await method_func(file_path_obj, pdf_path)
            print(f"      Result: {result}")
            if result and pdf_path.exists():
                print(f"      PDF size: {pdf_path.stat().st_size} bytes")
                # Clean up test PDF
                pdf_path.unlink()
        except Exception as e:
            print(f"      Error: {e}")
    
    # Test full conversion
    print(f"\n🔄 Full Conversion Test:")
    try:
        result = await fc.convert_to_pdf(file_path_obj, '.docx')
        print(f"   Result: {result}")
        if result and result.exists():
            print(f"   PDF size: {result.stat().st_size} bytes")
            print(f"   PDF path: {result}")
            # Clean up test PDF
            result.unlink()
    except Exception as e:
        print(f"   Error: {e}")
        import traceback
        traceback.print_exc()

async def main():
    """Main function"""
    if len(sys.argv) != 2:
        print("Usage: python check_file_health.py <path_to_docx_file>")
        print("Example: python check_file_health.py uploads/app147212-114793-valerio-gian-yuri-bondoc-.docx")
        return
    
    file_path = sys.argv[1]
    await check_file_health(file_path)

if __name__ == "__main__":
    asyncio.run(main())
